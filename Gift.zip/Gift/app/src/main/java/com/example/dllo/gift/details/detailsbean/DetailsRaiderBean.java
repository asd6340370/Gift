package com.example.dllo.gift.details.detailsbean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by dllo on 16/6/3.
 */
public class DetailsRaiderBean {

    /**
     * code : 200
     * data : {"ad_monitors":null,"comments_count":29,"content_html":"\n\n<!DOCTYPE html>\n<html>\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"renderer\" content=\"webkit\">\n    <meta name=\"format-detection\" content=\"telephone=no\">\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=Edge\">\n    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">\n    <meta id=\"vp\" name=\"viewport\" content=\"width=device-width, user-scalable=no,maximum-scale=1.0,initial-scale=1\">\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"http://static.liwushuo.com/static/web/apps/liwushuo/css/post_ccdd57d.css\">\n    <title>文章内容<\/title>\n    <script src=\"http://static.liwushuo.com/static/web/scripts/raven.min.js\"><\/script>\n    <script>\n      Raven.config('http://359d75d0ea0548089d1f944f5a14a03e@sentry.liwushuo.com/4').install();\n      var API_ENDPOINT = \"http://api.liwushuo.com\";\n      var POST_ID = \"1024345\";\n      var _IS_SUPPORT_SWIPER = \"True\";\n      document.addEventListener(\"DOMContentLoaded\", function(event) {\n        location.href = \"liwushuo:///notify?name=domloadfinish\";\n      });\n    <\/script>\n\n<\/head>\n<body id=\"body\">\n    <div class=\"wrapper\">\n      <div class=\"post\">\n        <div class=\"content\">\n        \n          \n\n          <p><a href=\"liwushuo:///page?type=topic&amp;page_action=navigation&amp;topic_id=256\"><img src=\"http://img01.liwushuo.com/image/160519/qv9wa3w4u.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160519/qv9wa3w4u.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:337}\" /><\/a><\/p>\n          <p>清新自然又干净的妆容相信是所有女生的追求，干净的妆容不仅会显现出五官的美丽，更是会提升整个人的气质，让整个人看起来精神气色好。想要拥有干净的妆容化妆品的准则固然重要，化妆工具的选择也是很重要的，正所谓&ldquo;好马配好鞍&rdquo;，优秀的化妆道具就像伯乐一样，可以挖掘化妆品的所有优点，使其凸显。小礼君为小伙伴们精心挑选了一些好用到爆棚的小工具，拥有他们，清新精致的妆容再也不是梦咯～<\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">1<\/span><span class=\"ititle\">KAI&bull;小刃修眉刀 L/T型2入<\/span><\/h3>\r\n<p>平时爱画点小妆，抹点小粉的同学们肯定都无比赞同&ldquo;眉毛比胸重要&rdquo;的概念！但无奈，眉毛周围的小杂毛总能以惊人的生长速度破坏我们原本打理好的完美眉型。在没有寻觅到这把修眉刀之前，小礼君也是&ldquo;完全不会修眉星人&rdquo;，面对杂乱无章的眉毛无从下手啊！但是用了之后，立马就感觉相见恨晚啊，修眉小能手就是这么样练成的哒～<img src=\"http://img01.liwushuo.com/image/151127/4czo518u1.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043028\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥15.00<\/span><\/p><p class=\"item-like-info\">704人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043028\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">2<\/span><span class=\"ititle\">Daiso&bull;眉毛定色定型液<\/span><\/h3>\r\n<p>号称&ldquo;眉毛雨衣&rdquo;的眉毛定型液，雨下再大都不怕～几乎人手一只，防水防汗防晕染，无色透明的白菜价好物，再也不用担心眉粉的脱色掉色造成的断眉影响整体妆容，画完眉毛后轻轻涂抹一层就能防止眉毛变淡或脱色断掉的尴尬状况啦～完美地保持一整天完美眉妆！<img src=\"http://img01.liwushuo.com/image/151127/xy1z0ves9.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043027\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥19.60<\/span><\/p><p class=\"item-like-info\">2094人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043027\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">3<\/span><span class=\"ititle\">Daiso&bull;化妆刷专用清洁液<\/span><\/h3>\r\n<p>大家的蜜粉扑，化妆刷，气垫粉扑一定要经常清洗哦，化妆工具的洁净对于精致清爽的妆容打造可是很重要的哦！大创这款清洗液清洁力度很强，可以彻底清除积粉，并且温和不刺激，一点都不伤小伙伴们心爱的化妆工具哦，无香料无色素，也不伤手，赞到不行哦！<img src=\"http://img03.liwushuo.com/image/151127/2au1jzhm6.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043030\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥19.80<\/span><\/p><p class=\"item-like-info\">1241人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043030\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">4<\/span><span class=\"ititle\">brush egg&bull;化妆刷洗刷蛋<\/span><\/h3>\r\n<p>为了保证化妆刷的清爽干净出了必备的清洗液，小小的&ldquo;洗刷板&rdquo;也是必备哦，不仅可以把刷子洗得干干净净，而且自身颜值也是很高哒！硅胶触感，质地柔软，不用担心会损伤刷子，彻底清洗净彩妆残留，小小一只，携带也是超方便的说～<img src=\"http://img03.liwushuo.com/image/151127/64z9ytcko.jpg-w720\" alt=\"\" /><img src=\"http://img02.liwushuo.com/image/151127/641gtxyq6.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043033\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥25.00<\/span><\/p><p class=\"item-like-info\">974人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043033\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">5<\/span><span class=\"ititle\">Clio&bull;气垫粉扑<\/span><\/h3>\r\n<p>气垫BB或粉底自带的粉扑用久了妆容看起来就不是那么得清新自然了，这时候就需要更换一下粉扑了哦，这样才可以保持住美好的妆容。CLIO家的粉扑， 被称为鸡蛋般触感，幼滑细腻，质感超棒！有气垫的小伙伴们快来备上吧！<img src=\"http://img02.liwushuo.com/image/151127/ia0688ix1.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043032\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥26.70<\/span><\/p><p class=\"item-like-info\">719人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043032\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">6<\/span><span class=\"ititle\">KAI&bull;修眉画眉辅助器 <\/span><\/h3>\r\n<p>这款辅助器与一般的眉型卡不同哦，就算修眉的时候也能起到辅助作用，简直打破眉毛这一时机难题，把修眉步骤化繁为简，帮助打造完美眉型。而且还有多款眉型可选，还有眉卡在手，画起来也是十分轻松啦，从修整到画型，让你时刻拥有无懈可击的精致双眉。<img src=\"http://img01.liwushuo.com/image/151127/jns7kwoqf.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043029\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥39.00<\/span><\/p><p class=\"item-like-info\">950人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043029\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">7<\/span><span class=\"ititle\">日本DUP美妆假睫毛胶水<\/span><\/h3>\r\n<p>cosme第一位睫毛胶水，防水、防汗、附着力超强，能维持一整天，决不轻易剥落，极细毛笔头型，使用轻松简单，好涂抹。dup的假睫毛胶水相信大家都不陌生吧，推荐过很多次的睫毛胶，也是小超近几年来最爱的胶水，真的是超级好用。它是韩国生产日本进口的，这点比较特殊哦~<img src=\"http://img03.liwushuo.com/image/160523/vvtxbvsng.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160523/vvtxbvsng.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:640}\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1038437\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥59.00<\/span><\/p><p class=\"item-like-info\">2501人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1038437\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">8<\/span><span class=\"ititle\">EYECURL&bull;电烫睫毛器<\/span><\/h3>\r\n<p>想拥有闪电大眼绝对少不了它，一节五号电池装上就能用，弧度非常自然，温度适中加热迅速，刷完睫毛就可以开启开关了，加热的时候刚好等睫毛膏干掉，最重要的是，它还可以带走睫毛上多余的睫毛膏，让睫毛根根分明！<img src=\"http://img02.liwushuo.com/image/151127/vwa42j23u.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043031\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥45.00<\/span><\/p><p class=\"item-like-info\">2042人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043031\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">9<\/span><span class=\"ititle\">KATE&bull;惊艳打底睫毛膏<\/span><\/h3>\r\n<p>这款睫毛打底大家可能已经知道了，但是小礼君一定要再说一遍，真的是超级好用！主要功效是给睫毛持久定型，不过最惊艳的地方，就是里面的黑色纤维，居然擦上后有一种嫁接睫毛的功效，整个睫毛看起来超长，再加上卷翘定型，整个睫毛又卷又翘，大眼妆so easy～<img src=\"http://img01.liwushuo.com/image/151127/q8ukbnl4x.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1043034\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥68.00<\/span><\/p><p class=\"item-like-info\">960人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1043034\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard off\"><\/a><\/div><\/p>\r\n<h3 class=\"item-title\"><span class=\"ititle-serial\">10<\/span><span class=\"ititle\">Real Techniques&middot;初学者化妆刷套装<\/span><\/h3>\r\n<p>Real Techniques是英国知名化妆设计师的自创品牌，走平价高质量路线，设计合理可以根据自己的需要选择不同的刷子套装，只要是化妆需要的刷子种类全都有！刷毛柔软不掉毛，用他们化妆不仅可以为你节省化妆时间，更重要的是可以是整体妆容呈现出清透自然的状态。<img src=\"http://img03.liwushuo.com/image/151127/dzet8n22l.jpg-w720\" alt=\"\" /><\/p>\r\n<p><div class=\"item-info\" data-id=\"1056743\"><p class=\"item-info-price\"><span style=\"font-family: arial;\">￥99.00<\/span><\/p><p class=\"item-like-info\">706人喜欢<\/p><a class=\"item-info-link\" href=\"http://www.liwushuo.com/items/1056743\" target=\"_blank\"><span>查看详情<\/span><\/a><a class=\"item-info-safeguard on\"><\/a><\/div><\/p>\r\n<h2 class=\"section-title\">本期话题<\/h2>\r\n<p>泥萌还有哪些能助化妆一臂之力的小工具吗？<\/p>\r\n<h2 class=\"section-title\">第20期评论获赞最高用户：左右76849<\/h2>\n          <p><a href=\"http://s.click.taobao.com/UUwSMXx?lws=4\"><img src=\"http://img03.liwushuo.com/image/160603/5isnu0n7g.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160603/5isnu0n7g.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:256}\" /><\/a><\/p>\r\n<p><img src=\"http://img03.liwushuo.com/image/160519/bv3x32sd3.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160519/bv3x32sd3.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:455}\" /><\/p>\n          \n          \n            \n  \n  <div id=\"invite_user_credit\">\n    <a href=\"liwushuo:///page?url=http%3A%2F%2Fwww.liwushuo.com%2Fcredit%2Fmy_invitation&amp;page_action=navigation&amp;login=true&amp;type=url\" class=\"\">\n      <img src=\"http://img03.liwushuo.com/image/160511/sgcgl88bi.jpg-w720\" alt=\"\" data-payload=\"{\"url\":\"http://img03.liwushuo.com/image/160511/sgcgl88bi.jpg-w720\",\"width\":640,\"height\":231}\">\n    <\/a>\n  <\/div>\n\n          \n          <div id=\"share-tip\" class=\"share-tip\"><\/div>\n        <\/div>\n        <div class=\"recommond-container\">\n          <div class=\"cross\">\n            <span class=\"cross-line\"><\/span>\n            <span class=\"cross-text\">你可能也喜欢<\/span>\n          <\/div>\n          <div id=\"postList\" scroll=\"no\"><\/div>\n          <div class=\"hide-scroll-bar\"><\/div>\n        <\/div>\n      <\/div>\n    <\/div>\n\n    <script type=\"text/javascript\">var require,define;!function(e){function r(e,r){function t(){clearTimeout(a)}if(!(e in u)){u[e]=!0;var i=document.createElement(\"script\");if(r){var a=setTimeout(r,require.timeout);i.onerror=function(){clearTimeout(a),r()},\"onload\"in i?i.onload=t:i.onreadystatechange=function(){(\"loaded\"==this.readyState||\"complete\"==this.readyState)&&t()}}return i.type=\"text/javascript\",i.src=e,n.appendChild(i),i}}function t(e,t,n){var a=i[e]||(i[e]=[]);a.push(t);var o,u=s[e]||{},f=u.pkg;o=f?c[f].url:u.url||e,r(o,n&&function(){n(e)})}var n=document.getElementsByTagName(\"head\")[0],i={},a={},o={},u={},s={},c={};define=function(e,r){a[e]=r;var t=i[e];if(t){for(var n=0,o=t.length;o>n;n++)t[n]();delete i[e]}},require=function(e){if(e&&e.splice)return require.async.apply(this,arguments);e=require.alias(e);var r=o[e];if(r)return r.exports;var t=a[e];if(!t)throw\"[ModJS] Cannot find module `\"+e+\"`\";r=o[e]={exports:{}};var n=\"function\"==typeof t?t.apply(r,[require,r.exports,r]):t;return n&&(r.exports=n),r.exports},require.async=function(r,n,i){function o(e){for(var r=0,n=e.length;n>r;r++){var c=e[r];if(c in a){var f=s[c];f&&\"deps\"in f&&o(f.deps)}else if(!(c in l)){l[c]=!0,p++,t(c,u,i);var f=s[c];f&&\"deps\"in f&&o(f.deps)}}}function u(){if(0==p--){for(var t=[],i=0,a=r.length;a>i;i++)t[i]=require(r[i]);n&&n.apply(e,t)}}\"string\"==typeof r&&(r=[r]);for(var c=0,f=r.length;f>c;c++)r[c]=require.alias(r[c]);var l={},p=0;o(r),u()},require.resourceMap=function(e){var r,t;t=e.res;for(r in t)t.hasOwnProperty(r)&&(s[r]=t[r]);t=e.pkg;for(r in t)t.hasOwnProperty(r)&&(c[r]=t[r])},require.loadJs=function(e){r(e)},require.loadCss=function(e){if(e.content){var r=document.createElement(\"style\");r.type=\"text/css\",r.styleSheet?r.styleSheet.cssText=e.content:r.innerHTML=e.content,n.appendChild(r)}else if(e.url){var t=document.createElement(\"link\");t.href=e.url,t.rel=\"stylesheet\",t.type=\"text/css\",n.appendChild(t)}},require.alias=function(e){return e},require.timeout=5e3}(this);<\/script>\n    <script type=\"text/javascript\" src=\"http://static.liwushuo.com/static/web/components/jquery/jquery_d107a7d.js\"><\/script>\n<script type=\"text/javascript\" src=\"http://static.liwushuo.com/static/web/scripts/util/request_5010967.js\"><\/script>\n<script type=\"text/javascript\" src=\"http://static.liwushuo.com/static/web/pkg/lib_27487aa.js\"><\/script>\n<script type=\"text/javascript\" src=\"http://static.liwushuo.com/static/web/apps/liwushuo/js/post-content_6419708.js\"><\/script>\n<script type=\"text/javascript\" src=\"http://static.liwushuo.com/static/web/apps/liwushuo/js/post-content-old_b40edb2.js\"><\/script>\n\n    <script>\n      var adjustPaddingTop = window.adjustPaddingTop = function (v) { \n        document.getElementById('body').style.paddingTop = (v + 'px'); \n      };\n\n      \n        require(\"liwushuo/post-content\");\n      \n\n      $('.post').find('a').each(function() {\n        var that = this;\n        var ids = that.href.match(/\\.com\\/collections\\/(\\d+)/);\n        if (ids) {\n          var id = ids[1];\n          $(that).attr('href', ('liwushuo:///page?type=topic&page_action=navigation&topic_id=' + id));\n        }\n      });\n    <\/script>\n<\/body>\n<\/html>","content_type":1,"content_url":"http://www.liwushuo.com/posts/1024345/content","cover_image_url":"http://img03.liwushuo.com/image/160523/axpolcaqz.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160523/axpolcaqz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1464166800,"editor_id":1058,"feature_list":[],"id":1024345,"item_ad_monitors":{"1038437":[],"1043027":[],"1043028":[],"1043029":[],"1043030":[],"1043031":[],"1043032":[],"1043033":[],"1043034":[],"1056743":[]},"label_ids":[],"liked":false,"likes_count":30298,"published_at":1464166800,"share_msg":"分享自@礼物说\u201490 后生活方式指南","shares_count":318,"short_title":"美妆工具推荐","status":0,"template":"","title":"第21期 | 化妆神器现身，手残星人也能画出完美妆容！","updated_at":1448603419,"url":"http://www.liwushuo.com/posts/1024345"}
     * message : OK
     */

    private int code;
    /**
     * ad_monitors : null
     * comments_count : 29
     * content_html :

     <!DOCTYPE html>
     <html>
     <head>
     <meta charset="UTF-8">
     <meta name="renderer" content="webkit">
     <meta name="format-detection" content="telephone=no">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="apple-mobile-web-app-capable" content="yes">
     <meta name="apple-mobile-web-app-status-bar-style" content="black">
     <meta id="vp" name="viewport" content="width=device-width, user-scalable=no,maximum-scale=1.0,initial-scale=1">
     <link rel="stylesheet" type="text/css" href="http://static.liwushuo.com/static/web/apps/liwushuo/css/post_ccdd57d.css">
     <title>文章内容</title>
     <script src="http://static.liwushuo.com/static/web/scripts/raven.min.js"></script>
     <script>
     Raven.config('http://359d75d0ea0548089d1f944f5a14a03e@sentry.liwushuo.com/4').install();
     var API_ENDPOINT = "http://api.liwushuo.com";
     var POST_ID = "1024345";
     var _IS_SUPPORT_SWIPER = "True";
     document.addEventListener("DOMContentLoaded", function(event) {
     location.href = "liwushuo:///notify?name=domloadfinish";
     });
     </script>

     </head>
     <body id="body">
     <div class="wrapper">
     <div class="post">
     <div class="content">



     <p><a href="liwushuo:///page?type=topic&amp;page_action=navigation&amp;topic_id=256"><img src="http://img01.liwushuo.com/image/160519/qv9wa3w4u.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160519/qv9wa3w4u.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:337}" /></a></p>
     <p>清新自然又干净的妆容相信是所有女生的追求，干净的妆容不仅会显现出五官的美丽，更是会提升整个人的气质，让整个人看起来精神气色好。想要拥有干净的妆容化妆品的准则固然重要，化妆工具的选择也是很重要的，正所谓&ldquo;好马配好鞍&rdquo;，优秀的化妆道具就像伯乐一样，可以挖掘化妆品的所有优点，使其凸显。小礼君为小伙伴们精心挑选了一些好用到爆棚的小工具，拥有他们，清新精致的妆容再也不是梦咯～</p>
     <h3 class="item-title"><span class="ititle-serial">1</span><span class="ititle">KAI&bull;小刃修眉刀 L/T型2入</span></h3>
     <p>平时爱画点小妆，抹点小粉的同学们肯定都无比赞同&ldquo;眉毛比胸重要&rdquo;的概念！但无奈，眉毛周围的小杂毛总能以惊人的生长速度破坏我们原本打理好的完美眉型。在没有寻觅到这把修眉刀之前，小礼君也是&ldquo;完全不会修眉星人&rdquo;，面对杂乱无章的眉毛无从下手啊！但是用了之后，立马就感觉相见恨晚啊，修眉小能手就是这么样练成的哒～<img src="http://img01.liwushuo.com/image/151127/4czo518u1.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043028"><p class="item-info-price"><span style="font-family: arial;">￥15.00</span></p><p class="item-like-info">704人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043028" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">2</span><span class="ititle">Daiso&bull;眉毛定色定型液</span></h3>
     <p>号称&ldquo;眉毛雨衣&rdquo;的眉毛定型液，雨下再大都不怕～几乎人手一只，防水防汗防晕染，无色透明的白菜价好物，再也不用担心眉粉的脱色掉色造成的断眉影响整体妆容，画完眉毛后轻轻涂抹一层就能防止眉毛变淡或脱色断掉的尴尬状况啦～完美地保持一整天完美眉妆！<img src="http://img01.liwushuo.com/image/151127/xy1z0ves9.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043027"><p class="item-info-price"><span style="font-family: arial;">￥19.60</span></p><p class="item-like-info">2094人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043027" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">3</span><span class="ititle">Daiso&bull;化妆刷专用清洁液</span></h3>
     <p>大家的蜜粉扑，化妆刷，气垫粉扑一定要经常清洗哦，化妆工具的洁净对于精致清爽的妆容打造可是很重要的哦！大创这款清洗液清洁力度很强，可以彻底清除积粉，并且温和不刺激，一点都不伤小伙伴们心爱的化妆工具哦，无香料无色素，也不伤手，赞到不行哦！<img src="http://img03.liwushuo.com/image/151127/2au1jzhm6.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043030"><p class="item-info-price"><span style="font-family: arial;">￥19.80</span></p><p class="item-like-info">1241人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043030" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">4</span><span class="ititle">brush egg&bull;化妆刷洗刷蛋</span></h3>
     <p>为了保证化妆刷的清爽干净出了必备的清洗液，小小的&ldquo;洗刷板&rdquo;也是必备哦，不仅可以把刷子洗得干干净净，而且自身颜值也是很高哒！硅胶触感，质地柔软，不用担心会损伤刷子，彻底清洗净彩妆残留，小小一只，携带也是超方便的说～<img src="http://img03.liwushuo.com/image/151127/64z9ytcko.jpg-w720" alt="" /><img src="http://img02.liwushuo.com/image/151127/641gtxyq6.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043033"><p class="item-info-price"><span style="font-family: arial;">￥25.00</span></p><p class="item-like-info">974人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043033" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">5</span><span class="ititle">Clio&bull;气垫粉扑</span></h3>
     <p>气垫BB或粉底自带的粉扑用久了妆容看起来就不是那么得清新自然了，这时候就需要更换一下粉扑了哦，这样才可以保持住美好的妆容。CLIO家的粉扑， 被称为鸡蛋般触感，幼滑细腻，质感超棒！有气垫的小伙伴们快来备上吧！<img src="http://img02.liwushuo.com/image/151127/ia0688ix1.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043032"><p class="item-info-price"><span style="font-family: arial;">￥26.70</span></p><p class="item-like-info">719人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043032" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">6</span><span class="ititle">KAI&bull;修眉画眉辅助器 </span></h3>
     <p>这款辅助器与一般的眉型卡不同哦，就算修眉的时候也能起到辅助作用，简直打破眉毛这一时机难题，把修眉步骤化繁为简，帮助打造完美眉型。而且还有多款眉型可选，还有眉卡在手，画起来也是十分轻松啦，从修整到画型，让你时刻拥有无懈可击的精致双眉。<img src="http://img01.liwushuo.com/image/151127/jns7kwoqf.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043029"><p class="item-info-price"><span style="font-family: arial;">￥39.00</span></p><p class="item-like-info">950人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043029" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">7</span><span class="ititle">日本DUP美妆假睫毛胶水</span></h3>
     <p>cosme第一位睫毛胶水，防水、防汗、附着力超强，能维持一整天，决不轻易剥落，极细毛笔头型，使用轻松简单，好涂抹。dup的假睫毛胶水相信大家都不陌生吧，推荐过很多次的睫毛胶，也是小超近几年来最爱的胶水，真的是超级好用。它是韩国生产日本进口的，这点比较特殊哦~<img src="http://img03.liwushuo.com/image/160523/vvtxbvsng.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160523/vvtxbvsng.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:640}" /></p>
     <p><div class="item-info" data-id="1038437"><p class="item-info-price"><span style="font-family: arial;">￥59.00</span></p><p class="item-like-info">2501人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1038437" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">8</span><span class="ititle">EYECURL&bull;电烫睫毛器</span></h3>
     <p>想拥有闪电大眼绝对少不了它，一节五号电池装上就能用，弧度非常自然，温度适中加热迅速，刷完睫毛就可以开启开关了，加热的时候刚好等睫毛膏干掉，最重要的是，它还可以带走睫毛上多余的睫毛膏，让睫毛根根分明！<img src="http://img02.liwushuo.com/image/151127/vwa42j23u.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043031"><p class="item-info-price"><span style="font-family: arial;">￥45.00</span></p><p class="item-like-info">2042人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043031" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">9</span><span class="ititle">KATE&bull;惊艳打底睫毛膏</span></h3>
     <p>这款睫毛打底大家可能已经知道了，但是小礼君一定要再说一遍，真的是超级好用！主要功效是给睫毛持久定型，不过最惊艳的地方，就是里面的黑色纤维，居然擦上后有一种嫁接睫毛的功效，整个睫毛看起来超长，再加上卷翘定型，整个睫毛又卷又翘，大眼妆so easy～<img src="http://img01.liwushuo.com/image/151127/q8ukbnl4x.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1043034"><p class="item-info-price"><span style="font-family: arial;">￥68.00</span></p><p class="item-like-info">960人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1043034" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard off"></a></div></p>
     <h3 class="item-title"><span class="ititle-serial">10</span><span class="ititle">Real Techniques&middot;初学者化妆刷套装</span></h3>
     <p>Real Techniques是英国知名化妆设计师的自创品牌，走平价高质量路线，设计合理可以根据自己的需要选择不同的刷子套装，只要是化妆需要的刷子种类全都有！刷毛柔软不掉毛，用他们化妆不仅可以为你节省化妆时间，更重要的是可以是整体妆容呈现出清透自然的状态。<img src="http://img03.liwushuo.com/image/151127/dzet8n22l.jpg-w720" alt="" /></p>
     <p><div class="item-info" data-id="1056743"><p class="item-info-price"><span style="font-family: arial;">￥99.00</span></p><p class="item-like-info">706人喜欢</p><a class="item-info-link" href="http://www.liwushuo.com/items/1056743" target="_blank"><span>查看详情</span></a><a class="item-info-safeguard on"></a></div></p>
     <h2 class="section-title">本期话题</h2>
     <p>泥萌还有哪些能助化妆一臂之力的小工具吗？</p>
     <h2 class="section-title">第20期评论获赞最高用户：左右76849</h2>
     <p><a href="http://s.click.taobao.com/UUwSMXx?lws=4"><img src="http://img03.liwushuo.com/image/160603/5isnu0n7g.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160603/5isnu0n7g.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:256}" /></a></p>
     <p><img src="http://img03.liwushuo.com/image/160519/bv3x32sd3.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160519/bv3x32sd3.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:455}" /></p>




     <div id="invite_user_credit">
     <a href="liwushuo:///page?url=http%3A%2F%2Fwww.liwushuo.com%2Fcredit%2Fmy_invitation&amp;page_action=navigation&amp;login=true&amp;type=url" class="">
     <img src="http://img03.liwushuo.com/image/160511/sgcgl88bi.jpg-w720" alt="" data-payload="{"url":"http://img03.liwushuo.com/image/160511/sgcgl88bi.jpg-w720","width":640,"height":231}">
     </a>
     </div>


     <div id="share-tip" class="share-tip"></div>
     </div>
     <div class="recommond-container">
     <div class="cross">
     <span class="cross-line"></span>
     <span class="cross-text">你可能也喜欢</span>
     </div>
     <div id="postList" scroll="no"></div>
     <div class="hide-scroll-bar"></div>
     </div>
     </div>
     </div>

     <script type="text/javascript">var require,define;!function(e){function r(e,r){function t(){clearTimeout(a)}if(!(e in u)){u[e]=!0;var i=document.createElement("script");if(r){var a=setTimeout(r,require.timeout);i.onerror=function(){clearTimeout(a),r()},"onload"in i?i.onload=t:i.onreadystatechange=function(){("loaded"==this.readyState||"complete"==this.readyState)&&t()}}return i.type="text/javascript",i.src=e,n.appendChild(i),i}}function t(e,t,n){var a=i[e]||(i[e]=[]);a.push(t);var o,u=s[e]||{},f=u.pkg;o=f?c[f].url:u.url||e,r(o,n&&function(){n(e)})}var n=document.getElementsByTagName("head")[0],i={},a={},o={},u={},s={},c={};define=function(e,r){a[e]=r;var t=i[e];if(t){for(var n=0,o=t.length;o>n;n++)t[n]();delete i[e]}},require=function(e){if(e&&e.splice)return require.async.apply(this,arguments);e=require.alias(e);var r=o[e];if(r)return r.exports;var t=a[e];if(!t)throw"[ModJS] Cannot find module `"+e+"`";r=o[e]={exports:{}};var n="function"==typeof t?t.apply(r,[require,r.exports,r]):t;return n&&(r.exports=n),r.exports},require.async=function(r,n,i){function o(e){for(var r=0,n=e.length;n>r;r++){var c=e[r];if(c in a){var f=s[c];f&&"deps"in f&&o(f.deps)}else if(!(c in l)){l[c]=!0,p++,t(c,u,i);var f=s[c];f&&"deps"in f&&o(f.deps)}}}function u(){if(0==p--){for(var t=[],i=0,a=r.length;a>i;i++)t[i]=require(r[i]);n&&n.apply(e,t)}}"string"==typeof r&&(r=[r]);for(var c=0,f=r.length;f>c;c++)r[c]=require.alias(r[c]);var l={},p=0;o(r),u()},require.resourceMap=function(e){var r,t;t=e.res;for(r in t)t.hasOwnProperty(r)&&(s[r]=t[r]);t=e.pkg;for(r in t)t.hasOwnProperty(r)&&(c[r]=t[r])},require.loadJs=function(e){r(e)},require.loadCss=function(e){if(e.content){var r=document.createElement("style");r.type="text/css",r.styleSheet?r.styleSheet.cssText=e.content:r.innerHTML=e.content,n.appendChild(r)}else if(e.url){var t=document.createElement("link");t.href=e.url,t.rel="stylesheet",t.type="text/css",n.appendChild(t)}},require.alias=function(e){return e},require.timeout=5e3}(this);</script>
     <script type="text/javascript" src="http://static.liwushuo.com/static/web/components/jquery/jquery_d107a7d.js"></script>
     <script type="text/javascript" src="http://static.liwushuo.com/static/web/scripts/util/request_5010967.js"></script>
     <script type="text/javascript" src="http://static.liwushuo.com/static/web/pkg/lib_27487aa.js"></script>
     <script type="text/javascript" src="http://static.liwushuo.com/static/web/apps/liwushuo/js/post-content_6419708.js"></script>
     <script type="text/javascript" src="http://static.liwushuo.com/static/web/apps/liwushuo/js/post-content-old_b40edb2.js"></script>

     <script>
     var adjustPaddingTop = window.adjustPaddingTop = function (v) {
     document.getElementById('body').style.paddingTop = (v + 'px');
     };


     require("liwushuo/post-content");


     $('.post').find('a').each(function() {
     var that = this;
     var ids = that.href.match(/\.com\/collections\/(\d+)/);
     if (ids) {
     var id = ids[1];
     $(that).attr('href', ('liwushuo:///page?type=topic&page_action=navigation&topic_id=' + id));
     }
     });
     </script>
     </body>
     </html>
     * content_type : 1
     * content_url : http://www.liwushuo.com/posts/1024345/content
     * cover_image_url : http://img03.liwushuo.com/image/160523/axpolcaqz.jpg-w720
     * cover_webp_url : http://img03.liwushuo.com/image/160523/axpolcaqz.jpg?imageView2/2/w/720/q/85/format/webp
     * created_at : 1464166800
     * editor_id : 1058
     * feature_list : []
     * id : 1024345
     * item_ad_monitors : {"1038437":[],"1043027":[],"1043028":[],"1043029":[],"1043030":[],"1043031":[],"1043032":[],"1043033":[],"1043034":[],"1056743":[]}
     * label_ids : []
     * liked : false
     * likes_count : 30298
     * published_at : 1464166800
     * share_msg : 分享自@礼物说—90 后生活方式指南
     * shares_count : 318
     * short_title : 美妆工具推荐
     * status : 0
     * template :
     * title : 第21期 | 化妆神器现身，手残星人也能画出完美妆容！
     * updated_at : 1448603419
     * url : http://www.liwushuo.com/posts/1024345
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        private Object ad_monitors;
        private int comments_count;
        private String content_html;
        private int content_type;
        private String content_url;
        private String cover_image_url;
        private String cover_webp_url;
        private int created_at;
        private int editor_id;
        private int id;
        private ItemAdMonitorsBean item_ad_monitors;
        private boolean liked;
        private int likes_count;
        private int published_at;
        private String share_msg;
        private int shares_count;
        private String short_title;
        private int status;
        private String template;
        private String title;
        private int updated_at;
        private String url;
        private List<?> feature_list;
        private List<?> label_ids;

        public Object getAd_monitors() {
            return ad_monitors;
        }

        public void setAd_monitors(Object ad_monitors) {
            this.ad_monitors = ad_monitors;
        }

        public int getComments_count() {
            return comments_count;
        }

        public void setComments_count(int comments_count) {
            this.comments_count = comments_count;
        }

        public String getContent_html() {
            return content_html;
        }

        public void setContent_html(String content_html) {
            this.content_html = content_html;
        }

        public int getContent_type() {
            return content_type;
        }

        public void setContent_type(int content_type) {
            this.content_type = content_type;
        }

        public String getContent_url() {
            return content_url;
        }

        public void setContent_url(String content_url) {
            this.content_url = content_url;
        }

        public String getCover_image_url() {
            return cover_image_url;
        }

        public void setCover_image_url(String cover_image_url) {
            this.cover_image_url = cover_image_url;
        }

        public String getCover_webp_url() {
            return cover_webp_url;
        }

        public void setCover_webp_url(String cover_webp_url) {
            this.cover_webp_url = cover_webp_url;
        }

        public int getCreated_at() {
            return created_at;
        }

        public void setCreated_at(int created_at) {
            this.created_at = created_at;
        }

        public int getEditor_id() {
            return editor_id;
        }

        public void setEditor_id(int editor_id) {
            this.editor_id = editor_id;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public ItemAdMonitorsBean getItem_ad_monitors() {
            return item_ad_monitors;
        }

        public void setItem_ad_monitors(ItemAdMonitorsBean item_ad_monitors) {
            this.item_ad_monitors = item_ad_monitors;
        }

        public boolean isLiked() {
            return liked;
        }

        public void setLiked(boolean liked) {
            this.liked = liked;
        }

        public int getLikes_count() {
            return likes_count;
        }

        public void setLikes_count(int likes_count) {
            this.likes_count = likes_count;
        }

        public int getPublished_at() {
            return published_at;
        }

        public void setPublished_at(int published_at) {
            this.published_at = published_at;
        }

        public String getShare_msg() {
            return share_msg;
        }

        public void setShare_msg(String share_msg) {
            this.share_msg = share_msg;
        }

        public int getShares_count() {
            return shares_count;
        }

        public void setShares_count(int shares_count) {
            this.shares_count = shares_count;
        }

        public String getShort_title() {
            return short_title;
        }

        public void setShort_title(String short_title) {
            this.short_title = short_title;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getTemplate() {
            return template;
        }

        public void setTemplate(String template) {
            this.template = template;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(int updated_at) {
            this.updated_at = updated_at;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public List<?> getFeature_list() {
            return feature_list;
        }

        public void setFeature_list(List<?> feature_list) {
            this.feature_list = feature_list;
        }

        public List<?> getLabel_ids() {
            return label_ids;
        }

        public void setLabel_ids(List<?> label_ids) {
            this.label_ids = label_ids;
        }

        public static class ItemAdMonitorsBean {
            @SerializedName("1038437")
            private List<?> value1038437;
            @SerializedName("1043027")
            private List<?> value1043027;
            @SerializedName("1043028")
            private List<?> value1043028;
            @SerializedName("1043029")
            private List<?> value1043029;
            @SerializedName("1043030")
            private List<?> value1043030;
            @SerializedName("1043031")
            private List<?> value1043031;
            @SerializedName("1043032")
            private List<?> value1043032;
            @SerializedName("1043033")
            private List<?> value1043033;
            @SerializedName("1043034")
            private List<?> value1043034;
            @SerializedName("1056743")
            private List<?> value1056743;

            public List<?> getValue1038437() {
                return value1038437;
            }

            public void setValue1038437(List<?> value1038437) {
                this.value1038437 = value1038437;
            }

            public List<?> getValue1043027() {
                return value1043027;
            }

            public void setValue1043027(List<?> value1043027) {
                this.value1043027 = value1043027;
            }

            public List<?> getValue1043028() {
                return value1043028;
            }

            public void setValue1043028(List<?> value1043028) {
                this.value1043028 = value1043028;
            }

            public List<?> getValue1043029() {
                return value1043029;
            }

            public void setValue1043029(List<?> value1043029) {
                this.value1043029 = value1043029;
            }

            public List<?> getValue1043030() {
                return value1043030;
            }

            public void setValue1043030(List<?> value1043030) {
                this.value1043030 = value1043030;
            }

            public List<?> getValue1043031() {
                return value1043031;
            }

            public void setValue1043031(List<?> value1043031) {
                this.value1043031 = value1043031;
            }

            public List<?> getValue1043032() {
                return value1043032;
            }

            public void setValue1043032(List<?> value1043032) {
                this.value1043032 = value1043032;
            }

            public List<?> getValue1043033() {
                return value1043033;
            }

            public void setValue1043033(List<?> value1043033) {
                this.value1043033 = value1043033;
            }

            public List<?> getValue1043034() {
                return value1043034;
            }

            public void setValue1043034(List<?> value1043034) {
                this.value1043034 = value1043034;
            }

            public List<?> getValue1056743() {
                return value1056743;
            }

            public void setValue1056743(List<?> value1056743) {
                this.value1056743 = value1056743;
            }
        }
    }
}
