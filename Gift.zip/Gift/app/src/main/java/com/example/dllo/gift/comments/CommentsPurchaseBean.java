package com.example.dllo.gift.comments;

import java.util.List;

/**
 * Created by dllo on 16/6/6.
 */
public class CommentsPurchaseBean {

    /**
     * code : 200
     * data : {"comments":[{"content":"学校门口精品店18我买了送同学","created_at":1453634172,"id":403660,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160124/1498e7c39_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5474806,"nickname":"南心不负","role":0}},{"content":"额","created_at":1447379454,"id":359121,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20151113/7mnmshctr_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":6138929,"nickname":"南昔烈酒。","role":0}},{"content":"已入 好看是好看 可太容易发热了 不能充电","created_at":1443286460,"id":239171,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160504/274266563_a-w180","can_mobile_login":false,"guest_uuid":"4101ebca-1673-45aa-908b-fed214badb8c","id":356529,"nickname":"幸好R","role":0}},{"content":"贵贵哒","created_at":1442677802,"id":232545,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/151104/c74a8b4e2_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5641172,"nickname":"北肆","role":0}},{"content":"这个到底好多钱啊？","created_at":1441092747,"id":206321,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150901/b936252ed_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":5483249,"nickname":"","role":0}},{"content":"好好看，要是有人送我就好了","created_at":1440992379,"id":203974,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150426/1ec6db905_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2080567,"nickname":"娜娜是个好菇凉","role":0}},{"content":"我滴少女心啊\u2026\u2026","created_at":1440917700,"id":201389,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150704/addf8580c_a-w180","can_mobile_login":false,"guest_uuid":null,"id":2623236,"nickname":"♔    葬心i","role":0}},{"content":"貌似是插电的","created_at":1440370383,"id":182606,"item_id":1005337,"replied_comment":{"content":"是充电的还是插电源的？？我要送一个住宿舍的朋友，没有插座啊！！","created_at":1439474451,"id":154240,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user_id":5032471},"replied_user":{"avatar_url":"http://img01.liwushuo.com/avatar/150807/3e101758c_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5032471,"nickname":"13847656700","role":0},"reply_to_id":154240,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150805/e723c2cd2_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":5015235,"nickname":"果然","role":0}},{"content":"灰常好看！都舍不得送人了T^T","created_at":1439849985,"id":167964,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150717/25c65877f_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2785171,"nickname":"草玉玲","role":0}},{"content":"是充电的还是插电源的？？我要送一个住宿舍的朋友，没有插座啊！！","created_at":1439474451,"id":154240,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150807/3e101758c_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5032471,"nickname":"13847656700","role":0}},{"content":"有了它，麻麻再也不会担心我怕黑啦！","created_at":1439455792,"id":153445,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150411/372798256_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1925933,"nickname":"别把自己当废物","role":0}},{"content":"有了它，麻麻再也不会担心我怕黑啦！","created_at":1439455790,"id":153444,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150411/372798256_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1925933,"nickname":"别把自己当废物","role":0}},{"content":"赞","created_at":1439425857,"id":152146,"item_id":1005337,"replied_comment":{"content":"买来送人了很漂亮啊^_^","created_at":1423232518,"id":4130,"item_id":1005337,"reply_to_id":null,"show":true,"status":0,"user_id":1262273},"replied_user":{"avatar_url":"http://img03.liwushuo.com/avatar/20150206/o294inur9_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1262273,"nickname":"Cute1ce","role":0},"reply_to_id":4130,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150727/f4c3daa64_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2926161,"nickname":"SICV","role":0}},{"content":"这事灯塔好伐","created_at":1435193277,"id":54835,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20150819/aja491emv_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1835528,"nickname":"火星娃娃","role":0}},{"content":"买来送人了很漂亮啊^_^","created_at":1423232518,"id":4130,"item_id":1005337,"reply_to_id":null,"show":true,"status":0,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20150206/o294inur9_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1262273,"nickname":"Cute1ce","role":0}}],"paging":{"next_url":"http://api.liwushuo.com/v2/items/1005337/comments?limit=20&offset=20"}}
     * message : OK
     */

    private int code;
    /**
     * comments : [{"content":"学校门口精品店18我买了送同学","created_at":1453634172,"id":403660,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160124/1498e7c39_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5474806,"nickname":"南心不负","role":0}},{"content":"额","created_at":1447379454,"id":359121,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20151113/7mnmshctr_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":6138929,"nickname":"南昔烈酒。","role":0}},{"content":"已入 好看是好看 可太容易发热了 不能充电","created_at":1443286460,"id":239171,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160504/274266563_a-w180","can_mobile_login":false,"guest_uuid":"4101ebca-1673-45aa-908b-fed214badb8c","id":356529,"nickname":"幸好R","role":0}},{"content":"贵贵哒","created_at":1442677802,"id":232545,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/151104/c74a8b4e2_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5641172,"nickname":"北肆","role":0}},{"content":"这个到底好多钱啊？","created_at":1441092747,"id":206321,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150901/b936252ed_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":5483249,"nickname":"","role":0}},{"content":"好好看，要是有人送我就好了","created_at":1440992379,"id":203974,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150426/1ec6db905_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2080567,"nickname":"娜娜是个好菇凉","role":0}},{"content":"我滴少女心啊\u2026\u2026","created_at":1440917700,"id":201389,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150704/addf8580c_a-w180","can_mobile_login":false,"guest_uuid":null,"id":2623236,"nickname":"♔    葬心i","role":0}},{"content":"貌似是插电的","created_at":1440370383,"id":182606,"item_id":1005337,"replied_comment":{"content":"是充电的还是插电源的？？我要送一个住宿舍的朋友，没有插座啊！！","created_at":1439474451,"id":154240,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user_id":5032471},"replied_user":{"avatar_url":"http://img01.liwushuo.com/avatar/150807/3e101758c_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5032471,"nickname":"13847656700","role":0},"reply_to_id":154240,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150805/e723c2cd2_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":5015235,"nickname":"果然","role":0}},{"content":"灰常好看！都舍不得送人了T^T","created_at":1439849985,"id":167964,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150717/25c65877f_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2785171,"nickname":"草玉玲","role":0}},{"content":"是充电的还是插电源的？？我要送一个住宿舍的朋友，没有插座啊！！","created_at":1439474451,"id":154240,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150807/3e101758c_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5032471,"nickname":"13847656700","role":0}},{"content":"有了它，麻麻再也不会担心我怕黑啦！","created_at":1439455792,"id":153445,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150411/372798256_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1925933,"nickname":"别把自己当废物","role":0}},{"content":"有了它，麻麻再也不会担心我怕黑啦！","created_at":1439455790,"id":153444,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150411/372798256_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1925933,"nickname":"别把自己当废物","role":0}},{"content":"赞","created_at":1439425857,"id":152146,"item_id":1005337,"replied_comment":{"content":"买来送人了很漂亮啊^_^","created_at":1423232518,"id":4130,"item_id":1005337,"reply_to_id":null,"show":true,"status":0,"user_id":1262273},"replied_user":{"avatar_url":"http://img03.liwushuo.com/avatar/20150206/o294inur9_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1262273,"nickname":"Cute1ce","role":0},"reply_to_id":4130,"show":true,"status":1,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150727/f4c3daa64_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2926161,"nickname":"SICV","role":0}},{"content":"这事灯塔好伐","created_at":1435193277,"id":54835,"item_id":1005337,"reply_to_id":null,"show":true,"status":1,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20150819/aja491emv_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1835528,"nickname":"火星娃娃","role":0}},{"content":"买来送人了很漂亮啊^_^","created_at":1423232518,"id":4130,"item_id":1005337,"reply_to_id":null,"show":true,"status":0,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20150206/o294inur9_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1262273,"nickname":"Cute1ce","role":0}}]
     * paging : {"next_url":"http://api.liwushuo.com/v2/items/1005337/comments?limit=20&offset=20"}
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        /**
         * next_url : http://api.liwushuo.com/v2/items/1005337/comments?limit=20&offset=20
         */

        private PagingBean paging;
        /**
         * content : 学校门口精品店18我买了送同学
         * created_at : 1453634172
         * id : 403660
         * item_id : 1005337
         * reply_to_id : null
         * show : true
         * status : 1
         * user : {"avatar_url":"http://img02.liwushuo.com/avatar/160124/1498e7c39_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5474806,"nickname":"南心不负","role":0}
         */

        private List<CommentsBean> comments;

        public PagingBean getPaging() {
            return paging;
        }

        public void setPaging(PagingBean paging) {
            this.paging = paging;
        }

        public List<CommentsBean> getComments() {
            return comments;
        }

        public void setComments(List<CommentsBean> comments) {
            this.comments = comments;
        }

        public static class PagingBean {
            private String next_url;

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class CommentsBean {
            private String content;
            private int created_at;
            private int id;
            private int item_id;
            private Object reply_to_id;
            private boolean show;
            private int status;
            /**
             * avatar_url : http://img02.liwushuo.com/avatar/160124/1498e7c39_a-w180
             * can_mobile_login : true
             * guest_uuid : null
             * id : 5474806
             * nickname : 南心不负
             * role : 0
             */

            private UserBean user;

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public int getCreated_at() {
                return created_at;
            }

            public void setCreated_at(int created_at) {
                this.created_at = created_at;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getItem_id() {
                return item_id;
            }

            public void setItem_id(int item_id) {
                this.item_id = item_id;
            }

            public Object getReply_to_id() {
                return reply_to_id;
            }

            public void setReply_to_id(Object reply_to_id) {
                this.reply_to_id = reply_to_id;
            }

            public boolean isShow() {
                return show;
            }

            public void setShow(boolean show) {
                this.show = show;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public static class UserBean {
                private String avatar_url;
                private boolean can_mobile_login;
                private Object guest_uuid;
                private int id;
                private String nickname;
                private int role;

                public String getAvatar_url() {
                    return avatar_url;
                }

                public void setAvatar_url(String avatar_url) {
                    this.avatar_url = avatar_url;
                }

                public boolean isCan_mobile_login() {
                    return can_mobile_login;
                }

                public void setCan_mobile_login(boolean can_mobile_login) {
                    this.can_mobile_login = can_mobile_login;
                }

                public Object getGuest_uuid() {
                    return guest_uuid;
                }

                public void setGuest_uuid(Object guest_uuid) {
                    this.guest_uuid = guest_uuid;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getNickname() {
                    return nickname;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }

                public int getRole() {
                    return role;
                }

                public void setRole(int role) {
                    this.role = role;
                }
            }
        }
    }
}
