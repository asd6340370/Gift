package com.example.dllo.gift.category;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.example.dllo.gift.R;
import com.example.dllo.gift.base.BaseFragment;

import java.util.ArrayList;

/**
 * Created by dllo on 16/5/19.
 */
public class CategoryRaiderFragment extends BaseFragment {


    @Override
    public int setLayout() {
        return R.layout.fragment_category_raider;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
