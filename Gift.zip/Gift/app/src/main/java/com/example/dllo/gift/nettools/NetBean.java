package com.example.dllo.gift.nettools;

/**
 * Created by dllo on 16/5/28.
 */
public interface NetBean {
}
