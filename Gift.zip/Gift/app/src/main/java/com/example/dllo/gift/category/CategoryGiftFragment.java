package com.example.dllo.gift.category;

import android.view.View;

import com.example.dllo.gift.R;
import com.example.dllo.gift.base.BaseFragment;

/**
 * Created by dllo on 16/5/19.
 */
public class CategoryGiftFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_category_gift;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
