package com.example.dllo.gift.tools;

/**
 * Created by dllo on 16/6/4.
 */
public interface RecyclerOnClickListener {
    void onClick(int position);
}
