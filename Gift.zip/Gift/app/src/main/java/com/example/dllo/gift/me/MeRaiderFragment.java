package com.example.dllo.gift.me;

import android.view.View;

import com.example.dllo.gift.R;
import com.example.dllo.gift.base.BaseFragment;

/**
 * Created by dllo on 16/5/23.
 */
public class MeRaiderFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_me_raider;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
