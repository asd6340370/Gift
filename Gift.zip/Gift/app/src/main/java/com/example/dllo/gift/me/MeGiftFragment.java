package com.example.dllo.gift.me;

import android.view.View;

import com.example.dllo.gift.base.BaseFragment;

/**
 * Created by dllo on 16/5/23.
 */
public class MeGiftFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return 0;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
